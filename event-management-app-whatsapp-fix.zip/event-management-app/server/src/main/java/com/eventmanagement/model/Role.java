package com.eventmanagement.model;

public enum Role {
    USER,
    ADMIN
}

